function metrics = FoldMetrics(y, pred, indices, tree)
folds = unique(indices(:))';
metrics = zeros(numel(folds), 2 + 4 * size(pred,2));
for k = 1:numel(folds)
    testID = (indices == folds(k));
    n = sum(testID);
    metrics(k,1:2) = [folds(k),n];
    for j = 1:size(pred,2)
        p = pred(testID,j);
        [~,~,FH] = EvaHier_HierarchicalPrecisionAndRecall(y(testID),p,tree);
        TIE = EvaHier_TreeInducedError(y(testID),p,tree) / n;
        [~,~,FLCA] = EvaHier_HierarchicalLCAPrecisionAndRecall(y(testID),p,tree);
        metrics(k,3+4*(j-1):6+4*(j-1)) = [mean(y(testID)==p)*100,FH,TIE,FLCA];
    end
end
end
