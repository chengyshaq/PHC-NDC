function feature = mimr_features(data, tree)
%MIMR_FEATURES Run the original HFS-MIMR implementation on DD.
% These settings reproduce the saved DD rankings in the active experiment.
[X, Y] = create_SubTable2(data, tree);
feature = MIMR(X, Y, tree, 10, 0.1, 0.01, 10, 0);
end
