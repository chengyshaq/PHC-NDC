# Package contents and metric check

The package contains DD and Bridges only. Each dataset has its own SHA-256 manifest covering the train/test files, MIMR feature file, and ten cached node-output files. `LoadDataset` checks these files and verifies the fold assignments and labels before the experiment starts.

`run_experiment` applies PHC-NDC to one selected dataset. `run_all` runs DD and Bridges sequentially. Both entry points reuse the bundled base predictions and probabilities; feature selection and base-SVM training sources remain available but are not called by the fixed-output main run.

`check_experiment` compares ACC, hierarchical F1, and tree-induced error with the paper values rounded to four decimal places. The expected values are in `reference/paper_metrics.csv`.
