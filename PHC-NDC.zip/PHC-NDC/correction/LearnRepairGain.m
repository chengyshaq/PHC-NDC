function model = LearnRepairGain(trueLabel, basePred, predChild, childProb, tree, m0)
%LEARNREPAIRGAIN Fit leaf and route gain models on calibration samples.
% Source-to-target confusion defines a correction from target to source.
% m0 controls the total weight of shared observations for each rule.

%% Initialize
trueLabel = double(trueLabel(:));
basePred = double(basePred(:));
leafProbability = LeafProbability(childProb, tree);
leafNodes = tree_LeafNode(tree);
leafIndex = zeros(size(tree, 1), 1);
leafIndex(leafNodes) = 1:numel(leafNodes);

%% Directed confusion rules
% Source is confused as target; correction goes from target to source.
leafRules = LeafRules(trueLabel, basePred, tree, 1.0, 2);
routeRules = RouteRules(trueLabel, basePred, tree, 1.0, 2);
ancestor = false(size(tree, 1));
for label = unique(basePred)'
    ancestor(tree_Ancestor(tree, label, 1), label) = true;
end

%% Initialize rule models
ruleSet = {leafRules, routeRules};
ruleParameters = cell(2, 1);
outcomeCounts = cell(2, 1);
globalParameters = cell(2, 1);
nonconverged = zeros(2, 1);

%% Fit leaf and route models
for layerIndex = 1:2
    rules = ruleSet{layerIndex};
    ruleCount = size(rules, 1);
    ruleParameters{layerIndex} = zeros(ruleCount, 4);
    outcomeCounts{layerIndex} = zeros(ruleCount, 3);
    globalParameters{layerIndex} = zeros(1, 4);
    ownRatio = cell(ruleCount, 1);
    ownOutcome = cell(ruleCount, 1);
    poolRatio = zeros(0, 1);
    poolOutcome = zeros(0, 1);
    sourcePrediction = cell(size(tree, 1), 1);

    %% Rule observations
    for ruleIndex = 1:ruleCount
        source = rules(ruleIndex, 2);
        target = rules(ruleIndex, 3);
        if layerIndex == 1
            mask = basePred == target;
            sourceProb = leafProbability(mask, leafIndex(source));
            targetProb = leafProbability(mask, leafIndex(target));
            repaired = repmat(source, sum(mask), 1);
        else
            mask = reshape(ancestor(target, basePred), [], 1);
            sourceProb = childProb(mask, source);
            targetProb = childProb(mask, target);
            if isempty(sourcePrediction{source})
                sourcePrediction{source} = TopDownPath(predChild, tree, source);
            end
            repaired = sourcePrediction{source}(mask);
        end

        logRatio = log(max(sourceProb, 1e-12)) - log(max(targetProb, 1e-12));
        outcome = double(repaired == trueLabel(mask)) - double(basePred(mask) == trueLabel(mask));
        ownRatio{ruleIndex} = logRatio(:);
        ownOutcome{ruleIndex} = outcome(:);
        poolRatio = [poolRatio; logRatio(:)];
        poolOutcome = [poolOutcome; outcome(:)];
        outcomeCounts{layerIndex}(ruleIndex, :) = ...
            [sum(outcome == 1), sum(outcome == -1), sum(outcome == 0)];
    end

    if isempty(poolRatio)
        continue;
    end

    %% Shared observations
    [globalParameters{layerIndex}, converged] = ...
        FitRepairGain(poolRatio, poolOutcome, ones(size(poolRatio)));
    nonconverged(layerIndex) = nonconverged(layerIndex) + ~converged;
    poolWeight = m0 / numel(poolRatio);

    %% Rule-specific fitting
    for ruleIndex = 1:ruleCount
        ratio = ownRatio{ruleIndex};
        outcome = ownOutcome{ruleIndex};
        weight = [ones(numel(ratio), 1); poolWeight * ones(numel(poolRatio), 1)];
        [parameters, converged] = FitRepairGain([ratio; poolRatio], [outcome; poolOutcome], weight);
        ruleParameters{layerIndex}(ruleIndex, :) = parameters;
        nonconverged(layerIndex) = nonconverged(layerIndex) + ~converged;
    end

    assert(nonconverged(layerIndex) == 0, 'Gain model did not converge.');
    assert(all(isfinite(ruleParameters{layerIndex}), 'all'));
end

%% Output
model.leaf.rules = leafRules(:, 1:4);
model.leaf.parameters = ruleParameters{1};
model.leaf.outcomeCounts = outcomeCounts{1};
model.leaf.globalParameters = globalParameters{1};
model.leaf.nonconverged = nonconverged(1);
model.route.rules = routeRules(:, 1:4);
model.route.parameters = ruleParameters{2};
model.route.outcomeCounts = outcomeCounts{2};
model.route.globalParameters = globalParameters{2};
model.route.nonconverged = nonconverged(2);
model.m0 = m0;
model.regularization = 1e-3;
model.minimumSupport = 2;
model.input = 'log_probability_ratio';
model.outcomeOrder = {'fixed', 'broken', 'neutral'};
end
