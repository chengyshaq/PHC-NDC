function [parameters, converged, iterations] = FitRepairGain(logRatio, outcome, weight)
%FITREPAIRGAIN Fit the regularized fixed/broken/neutral softmax model.
% outcome is 1 for fixed, -1 for broken, and 0 for neutral.
% parameters: [fixed intercept, fixed slope, broken intercept, broken slope].

%% Initialize
logRatio = double(logRatio(:));
outcome = double(outcome(:));
weight = double(weight(:));
features = [ones(numel(logRatio), 1), logRatio];
parameters = zeros(4, 1);
converged = isempty(logRatio);
iterations = 0;
regularization = 1e-3;

if isempty(logRatio)
    return;
end
assert(all(isfinite(logRatio)) && all(weight > 0));
assert(all(ismember(outcome, [-1, 0, 1])));
classIndex = ones(numel(outcome), 1);
classIndex(outcome == 1) = 2;
classIndex(outcome == -1) = 3;

for iterations = 1:100
    %% Newton direction
    [loss, probabilities] = GainObjective(features, classIndex, weight, parameters, regularization);
    fixedProbability = probabilities(:, 2);
    brokenProbability = probabilities(:, 3);
    fixedGradient = features' * (weight .* (fixedProbability - (outcome == 1)));
    brokenGradient = features' * (weight .* (brokenProbability - (outcome == -1)));
    gradient = [fixedGradient; brokenGradient] + regularization * parameters;
    if norm(gradient, inf) < 1e-7
        converged = true;
        break;
    end
    fixedHessian = features' * ((weight .* fixedProbability .* (1 - fixedProbability)) .* features);
    brokenHessian = features' * ((weight .* brokenProbability .* (1 - brokenProbability)) .* features);
    crossHessian = features' * ((-weight .* fixedProbability .* brokenProbability) .* features);
    hessian = [fixedHessian, crossHessian; crossHessian, brokenHessian] + regularization * eye(4);
    direction = hessian \ gradient;
    if any(~isfinite(direction))
        break;
    end

    stepScale = 1;
    accepted = false;
    lossRoundoff = 32 * eps(max(1, abs(loss)));
    %% Armijo line search
    % Allow roundoff when the objective values are nearly equal.
    for backtrack = 1:35
        candidate = parameters - stepScale * direction;
        candidateLoss = GainObjective(features, classIndex, weight, candidate, regularization);
        if candidateLoss <= loss - 1e-4 * stepScale * (gradient' * direction) + lossRoundoff
            accepted = true;
            break;
        end
        stepScale = stepScale / 2;
    end

    if ~accepted
        break;
    end
    change = norm(candidate - parameters, inf);
    parameters = candidate;
    %% Convergence check
    if change < 1e-9
        [~, probabilities] = GainObjective(features, classIndex, weight, parameters, regularization);
        finalGradient = [features' * (weight .* (probabilities(:, 2) - (outcome == 1))); ...
            features' * (weight .* (probabilities(:, 3) - (outcome == -1)))] + regularization * parameters;
        converged = norm(finalGradient, inf) < 1e-5;
        if converged
            break;
        end
    end
end

%% Record a failed fit
if ~converged
    [finalLoss, finalProbability] = GainObjective(features, classIndex, weight, parameters, regularization);
    finalGradient = [features' * (weight .* (finalProbability(:, 2) - (outcome == 1))); ...
        features' * (weight .* (finalProbability(:, 3) - (outcome == -1)))] + regularization * parameters;
    save(fullfile(fileparts(mfilename('fullpath')), 'logs', 'fit_failure.mat'), ...
        'logRatio', 'outcome', 'weight', 'parameters', 'iterations', 'finalLoss', 'finalGradient');
    fprintf('[FITFAIL] iterations=%d gradient=%.9g loss=%.9g\n', ...
        iterations, norm(finalGradient, inf), finalLoss);
end
parameters = parameters(:)';
end

function [loss, probabilities] = GainObjective(features, classIndex, weight, parameters, regularization)
% Column order: neutral, fixed, broken.
scores = [zeros(size(features, 1), 1), features * reshape(parameters, 2, 2)];
maximum = max(scores, [], 2);
exponentials = exp(scores - maximum);
normalizer = sum(exponentials, 2);
probabilities = exponentials ./ normalizer;
selected = zeros(numel(classIndex), 1);
for sampleIndex = 1:numel(classIndex)
    selected(sampleIndex) = scores(sampleIndex, classIndex(sampleIndex));
end
loss = sum(weight .* (maximum + log(normalizer) - selected)) + ...
    regularization * sum(parameters.^2) / 2;
end
