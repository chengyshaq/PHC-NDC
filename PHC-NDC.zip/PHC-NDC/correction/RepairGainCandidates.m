function candidates = RepairGainCandidates(basePred, predChild, childProb, tree, model)
%REPAIRGAINCANDIDATES Score the best route and leaf correction per sample.
% Equal gains prefer greater support, then the smaller source node ID.

%% Initialize
basePred = double(basePred(:));
sampleCount = numel(basePred);
leafProbability = LeafProbability(childProb, tree);
leafNodes = tree_LeafNode(tree);
leafIndex = zeros(size(tree, 1), 1);
leafIndex(leafNodes) = 1:numel(leafNodes);
ancestor = false(size(tree, 1));
for label = unique(basePred)'
    ancestor(tree_Ancestor(tree, label, 1), label) = true;
end

leafRules = model.leaf.rules;
routeRules = model.route.rules;
leafParameters = model.leaf.parameters;
routeParameters = model.route.parameters;
leafPrediction = basePred;
routePrediction = basePred;
leafScore = -inf(sampleCount, 1);
routeScore = -inf(sampleCount, 1);
leafRuleID = zeros(sampleCount, 1);
routeRuleID = zeros(sampleCount, 1);
sourcePrediction = cell(size(tree, 1), 1);

%% Route candidates
for ruleIndex = 1:size(routeRules, 1)
    source = routeRules(ruleIndex, 2);
    target = routeRules(ruleIndex, 3);
    eligible = find(ancestor(target, basePred));
    if isempty(eligible)
        continue;
    end
    logRatio = log(max(childProb(eligible, source), 1e-12)) - ...
        log(max(childProb(eligible, target), 1e-12));
    gain = RepairGainScore(logRatio, routeParameters(ruleIndex, :));
    if isempty(sourcePrediction{source})
        sourcePrediction{source} = TopDownPath(predChild, tree, source);
    end
    for position = 1:numel(eligible)
        sampleIndex = eligible(position);
        previous = routeRuleID(sampleIndex);
        if gain(position) > routeScore(sampleIndex)
            better = true;
        elseif gain(position) == routeScore(sampleIndex) && previous > 0
            support = routeRules(ruleIndex, 4);
            previousSupport = routeRules(previous, 4);
            better = support > previousSupport || ...
                (support == previousSupport && source < routeRules(previous, 2));
        else
            better = false;
        end
        if better
            routeScore(sampleIndex) = gain(position);
            routeRuleID(sampleIndex) = ruleIndex;
            routePrediction(sampleIndex) = sourcePrediction{source}(sampleIndex);
        end
    end
end

%% Leaf candidates
for ruleIndex = 1:size(leafRules, 1)
    source = leafRules(ruleIndex, 2);
    target = leafRules(ruleIndex, 3);
    eligible = find(basePred == target);
    if isempty(eligible)
        continue;
    end
    logRatio = log(max(leafProbability(eligible, leafIndex(source)), 1e-12)) - ...
        log(max(leafProbability(eligible, leafIndex(target)), 1e-12));
    gain = RepairGainScore(logRatio, leafParameters(ruleIndex, :));
    for position = 1:numel(eligible)
        sampleIndex = eligible(position);
        previous = leafRuleID(sampleIndex);
        if gain(position) > leafScore(sampleIndex)
            better = true;
        elseif gain(position) == leafScore(sampleIndex) && previous > 0
            support = leafRules(ruleIndex, 4);
            previousSupport = leafRules(previous, 4);
            better = support > previousSupport || ...
                (support == previousSupport && source < leafRules(previous, 2));
        else
            better = false;
        end
        if better
            leafScore(sampleIndex) = gain(position);
            leafRuleID(sampleIndex) = ruleIndex;
            leafPrediction(sampleIndex) = source;
        end
    end
end

%% Output
candidates.base = basePred;
candidates.leafPrediction = leafPrediction;
candidates.routePrediction = routePrediction;
candidates.leafScore = leafScore;
candidates.routeScore = routeScore;
candidates.leafRuleID = leafRuleID;
candidates.routeRuleID = routeRuleID;
end
