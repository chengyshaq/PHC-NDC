function [prediction, fired] = SelectRepairGain(candidates, threshold)
%SELECTREPAIRGAIN Apply candidates whose gain exceeds the threshold.
% prediction columns: base, leaf, route, final.
% fired columns: leaf rule ID, route rule ID.

%% Initialize
leafPrediction = candidates.base;
routePrediction = candidates.base;
finalPrediction = candidates.base;
leafActive = candidates.leafRuleID > 0 & candidates.leafScore > threshold;
routeActive = candidates.routeRuleID > 0 & candidates.routeScore > threshold;

%% Apply corrections
for sampleIndex = 1:numel(candidates.base)
    if leafActive(sampleIndex)
        leafPrediction(sampleIndex) = candidates.leafPrediction(sampleIndex);
    end
    if routeActive(sampleIndex)
        routePrediction(sampleIndex) = candidates.routePrediction(sampleIndex);
    end
    % A route takes priority when it changes the base prediction.
    if routePrediction(sampleIndex) ~= candidates.base(sampleIndex)
        finalPrediction(sampleIndex) = routePrediction(sampleIndex);
    else
        finalPrediction(sampleIndex) = leafPrediction(sampleIndex);
    end
end

%% Output
prediction = [candidates.base, leafPrediction, routePrediction, finalPrediction];
fired = [candidates.leafRuleID .* leafActive, candidates.routeRuleID .* routeActive];
end
