function C = CorrectionMatrix(Nss, Nst, Nts, Ntt)
C = zeros(2,2);
if (Nss + Nts > 0)
    C(1,1) = Nss / (Nss + Nts);
    C(2,1) = Nts / (Nss + Nts);
else
    C(1,1) = 1;
    C(2,1) = 0;
end
if (Nst + Ntt > 0)
    C(1,2) = Nst / (Nst + Ntt);
    C(2,2) = Ntt / (Nst + Ntt);
else
    C(1,2) = 0;
    C(2,2) = 1;
end
end
