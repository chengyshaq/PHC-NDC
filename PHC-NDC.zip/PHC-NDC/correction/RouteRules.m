function rules = RouteRules(trueLabel, oofLabel, tree, kRatio, minSupport)
trueLabel = trueLabel(:);
oofLabel = oofLabel(:);
n = length(trueLabel);
numNodes = size(tree,1);
leafNode = tree_LeafNode(tree);
paths = cell(numNodes,1);
for currentNode = 1:numNodes
    paths{currentNode} = fliplr(tree_Ancestor(tree, currentNode, 1));
end
trueBranch = zeros(n,numNodes);
predBranch = zeros(n,numNodes);

%% Find the first divergence of each wrong prediction
direction = zeros(0,4);
for i = 1:n
    truePath = paths{trueLabel(i)};
    predPath = paths{oofLabel(i)};
    for j = 1:length(truePath)-1
        trueBranch(i,truePath(j)) = truePath(j+1);
    end
    for j = 1:length(predPath)-1
        predBranch(i,predPath(j)) = predPath(j+1);
    end
    if (trueLabel(i) == oofLabel(i))
        continue;
    end
    j = 1;
    while (truePath(j) == predPath(j))
        j = j + 1;
    end
    p = truePath(j-1);
    s = truePath(j);
    t = predPath(j);
    if (ismember(s,leafNode) && ismember(t,leafNode))
        continue;
    end
    row = find(direction(:,1) == p & direction(:,2) == s & direction(:,3) == t, 1);
    if (isempty(row))
        direction = [direction; p, s, t, 1];
    else
        direction(row,4) = direction(row,4) + 1;
    end
end
direction = direction(direction(:,4) >= minSupport,:);
direction = sortrows(direction, [-4, 1, 2, 3]);
direction = direction(1:ceil(kRatio * size(direction,1)),:);

%% Learn the correction matrix of each direction
rules = zeros(0,8);
for j = 1:size(direction,1)
    p = direction(j,1);
    s = direction(j,2);
    t = direction(j,3);
    tb = trueBranch(:,p);
    pb = predBranch(:,p);
    Nss = sum(tb == s & pb == s);
    Nst = sum(tb == s & pb == t);
    Nts = sum(tb == t & pb == s);
    Ntt = sum(tb == t & pb == t);
    C = CorrectionMatrix(Nss, Nst, Nts, Ntt);
    rules = [rules; p, s, t, direction(j,4), C(1,1), C(1,2), C(2,1), C(2,2)];
end

%% Order by target, count, Cst and source
rules = sortrows(rules, [3, -4, -6, 2]);
end

