function [threshold, validation] = CalibrateRepairGainThreshold( ...
        trueLabel, basePred, predChild, childProb, tree, m0)
%CALIBRATEREPAIRGAINTHRESHOLD Select a threshold by three-fold calibration.
% Rules and gain models are refitted within each inner training split.
% Ties prefer fewer changes, then the larger threshold.

%% Stratified calibration folds
trueLabel = double(trueLabel(:));
innerFolds = 3;
validationFold = zeros(numel(trueLabel), 1);

for label = unique(trueLabel)'
    indices = find(trueLabel == label);
    validationFold(indices) = mod((0:numel(indices) - 1)', innerFolds) + 1;
end

%% Three-fold validation
thresholds = [0, 0.005, 0.01, 0.02, 0.05, 0.1, inf];
validationPrediction = zeros(numel(trueLabel), numel(thresholds));
for fold = 1:innerFolds
    heldOut = validationFold == fold;
    if ~any(heldOut)
        continue;
    end

    model = LearnRepairGain(trueLabel(~heldOut), basePred(~heldOut), ...
        predChild(~heldOut, :), childProb(~heldOut, :), tree, m0);
    candidates = RepairGainCandidates(basePred(heldOut), predChild(heldOut, :), ...
        childProb(heldOut, :), tree, model);
    for thresholdIndex = 1:numel(thresholds)
        prediction = SelectRepairGain(candidates, thresholds(thresholdIndex));
        validationPrediction(heldOut, thresholdIndex) = prediction(:, 4);
    end
end

%% Select the threshold
% Ties prefer fewer changes, then the larger threshold.
correct = sum(validationPrediction == trueLabel, 1);
changed = sum(validationPrediction ~= basePred, 1);
bestIndex = 1;
for thresholdIndex = 2:numel(thresholds)
    if correct(thresholdIndex) > correct(bestIndex)
        bestIndex = thresholdIndex;
    elseif correct(thresholdIndex) == correct(bestIndex)
        if changed(thresholdIndex) <= changed(bestIndex)
            bestIndex = thresholdIndex;
        end
    end
end
threshold = thresholds(bestIndex);
fixed = sum(basePred ~= trueLabel & validationPrediction == trueLabel, 1);
broken = sum(basePred == trueLabel & validationPrediction ~= trueLabel, 1);

%% Validation record
validation.columns = {'Threshold', 'N', 'Correct', 'Fixed', 'Broken', 'Changed', 'Selected'};
validation.scan = [thresholds', repmat(numel(trueLabel), numel(thresholds), 1), ...
    correct', fixed', broken', changed', ((1:numel(thresholds))' == bestIndex)];
validation.fold = validationFold;
validation.prediction = validationPrediction;
validation.innerFolds = innerFolds;
end
