function [gain, probabilities] = RepairGainScore(logRatio, parameters)
%% Input
% logRatio: source-to-target log probability ratios.
% parameters: fixed and broken intercepts and slopes.
%% Output
% gain: probability of fixing minus probability of breaking.
% probabilities: [neutral, fixed, broken] probabilities.

%% Compute the logits and stable softmax probabilities
logRatio = double(logRatio(:));
features = [ones(numel(logRatio), 1), logRatio];
parameterMatrix = reshape(parameters, 2, 2);
scores = [zeros(numel(logRatio), 1), features * parameterMatrix];
scores = scores - max(scores, [], 2);
probabilities = exp(scores);
probabilities = probabilities ./ sum(probabilities, 2);
%% Net repair gain
gain = probabilities(:, 2) - probabilities(:, 3);
end
