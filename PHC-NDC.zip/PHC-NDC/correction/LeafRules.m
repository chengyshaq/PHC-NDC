function rules = LeafRules(trueLabel, oofLabel, tree, kRatio, minSupport)
trueLabel = trueLabel(:);
oofLabel = oofLabel(:);
leafNode = tree_LeafNode(tree);

%% Confusion directions between sibling leaves
direction = zeros(0,4);
for s = leafNode
    children_set = get_children_set(tree, tree(s,1));
    for t = children_set'
        if (t ~= s && ismember(t, leafNode))
            num = sum(trueLabel == s & oofLabel == t);
            if (num >= minSupport)
                rate = num / sum(trueLabel == s);
                direction = [direction; s, t, num, rate];
            end
        end
    end
end
direction = sortrows(direction, [-3, -4, 1, 2]);
direction = direction(1:ceil(kRatio * size(direction,1)), :);

%% Learn directed rule statistics
rules = zeros(0,8);
for i = 1:size(direction,1)
    s = direction(i,1);
    t = direction(i,2);
    Nss = sum(trueLabel == s & oofLabel == s);
    Nst = sum(trueLabel == s & oofLabel == t);
    Nts = sum(trueLabel == t & oofLabel == s);
    Ntt = sum(trueLabel == t & oofLabel == t);
    C = CorrectionMatrix(Nss, Nst, Nts, Ntt);
    rules = [rules; tree(s,1), s, t, direction(i,3), C(1,1), C(1,2), C(2,1), C(2,2)];
end

%% Preserve deterministic rule-ID ordering
rules = sortrows(rules, [3, -4, -6, 2]);
end
