function digest = FileSHA256(filename)
%FILESHA256 Hash complete input files when validating prediction caches.
fid = fopen(filename, 'rb');
assert(fid >= 0, 'Cannot open %s.', filename);
cleanup = onCleanup(@() fclose(fid));
engine = java.security.MessageDigest.getInstance('SHA-256');
while ~feof(fid)
    engine.update(fread(fid, 1048576, '*uint8'));
end
bytes = typecast(engine.digest(), 'uint8');
digest = lower(reshape(dec2hex(bytes, 2)', 1, []));
end
