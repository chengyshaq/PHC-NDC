function [calibrationLabel, testLabel, tree, indices, nodeOutputs] = LoadDataset(root, dataset)
%LOADDATASET Read one bundled DD or Bridges MIMR experiment.
% Node predictions and probabilities stay fixed during PHC-NDC learning.
dataset = validatestring(char(dataset), {'DD', 'Bridges'});
trainFile = fullfile(root, 'datasets', [dataset 'Train.mat']);
testFile = fullfile(root, 'datasets', [dataset 'Test.mat']);
featureFile = fullfile(root, 'features', [dataset '_feature.mat']);
assetDir = fullfile(root, 'assets', 'base_outputs', dataset);
manifest = jsondecode(fileread(fullfile(assetDir, 'manifest.json')));

%% Data and feature files
inputFiles = {trainFile, testFile, featureFile};
assert(strcmp(manifest.dataset, dataset), 'The selected dataset and cache manifest differ.');
assert(numel(manifest.inputs) == numel(inputFiles));
for k = 1:numel(inputFiles)
    assert(strcmp(FileSHA256(inputFiles{k}), manifest.inputs(k).sha256), ...
        'A bundled dataset or MIMR feature file has changed.');
end
trainSet = load(trainFile);
testSet = load(testFile);
selected = load(featureFile);
calibrationData = double(trainSet.data_array);
testData = double(testSet.data_array);
calibrationLabel = calibrationData(:, end);
testLabel = testData(:, end);
tree = double(trainSet.tree);
indices = double(selected.testIndices(:));
assert(isequal(tree, double(testSet.tree)), 'Dataset hierarchies differ.');
assert(size(calibrationData, 2) == size(testData, 2));
assert(numel(indices) == numel(testLabel));
assert(isequal(unique(indices)', 1:10), 'The paper ten-fold assignment is required.');
assert(isscalar(selected.numberSel) && selected.numberSel >= 1 ...
    && selected.numberSel <= size(calibrationData, 2) - 1);
assert(numel(selected.feature) == size(tree, 1));
assert(all(isfinite(calibrationData), 'all') && all(isfinite(testData), 'all'));

%% Node outputs for the ten outer folds
assert(numel(manifest.files) == 10, 'Ten original node-output files are required.');
nodeOutputs = cell(10, 1);
for fold = 1:10
    entry = manifest.files(fold);
    assert(strcmp(entry.file, sprintf('fold_%02d.mat', fold)));
    nodeFile = fullfile(assetDir, entry.file);
    assert(strcmp(FileSHA256(nodeFile), entry.sha256), ...
        'A paper node-output file has changed.');
    node = load(nodeFile);
    assert(isequal(node.testID, indices == fold) && isequal(node.tree, tree));
    assert(isequal(node.feature, selected.feature) && node.numberSel == selected.numberSel);
    assert(isequal(node.trainLabel, calibrationLabel));
    assert(isequal(node.testLabel, testLabel));
    nodeOutputs{fold} = node;
end
end
