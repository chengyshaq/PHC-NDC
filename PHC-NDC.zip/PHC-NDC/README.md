# PHC-NDC: DD and Bridges

This package contains only the DD and Bridges dataset inputs used in the paper's MIMR + PHC-NDC experiments. It includes the selected MIMR features and the fixed ten-fold node predictions and probabilities for each dataset. The upstream MIMR feature-selection, SVM training, and prediction source is retained.

## Run in MATLAB

From this directory, run both datasets with:

```matlab
run_all
```

To run one dataset only:

```matlab
run_experiment([], 'DD')
run_experiment([], 'Bridges')
```

Outputs are written to `results/DD` and `results/Bridges`. Compare a completed run with the paper's four-decimal metrics using:

```matlab
check_experiment([], 'DD')
check_experiment([], 'Bridges')
```

The main run uses the bundled node outputs. It does not rerun feature selection or retrain the base SVMs.
