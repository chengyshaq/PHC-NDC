function ok = check_experiment(outputDir, dataset)
%CHECK_EXPERIMENT Compare one output summary with the paper's rounded values.
root = setup_project;
if nargin < 2 || isempty(dataset)
    dataset = 'DD';
end
dataset = validatestring(char(dataset), {'DD', 'Bridges'});
if nargin < 1 || isempty(outputDir)
    outputDir = fullfile(root, 'results', dataset);
end

actual = readtable(fullfile(outputDir, 'summary.csv'));
expectedTable = readtable(fullfile(root, 'reference', 'paper_metrics.csv'));
row = find(strcmp(string(expectedTable.Dataset), dataset), 1);
assert(~isempty(row), 'No paper reference exists for the selected dataset.');
assert(height(actual) == 1 && strcmp(string(actual.Dataset(1)), dataset));
assert(strcmp(string(actual.Method(1)), 'MIMR'));

fields = {'BaseACC', 'PHCNDCACC', 'BaseFH', 'PHCNDCFH', 'BaseTIE', 'PHCNDCTIE'};
ok = true;
for k = 1:numel(fields)
    field = fields{k};
    value = actual.(field);
    expected = expectedTable.(field);
    expected = expected(row);
    matched = round(value(1), 4) == expected;
    ok = ok && matched;
    status = 'FAIL';
    if matched
        status = 'PASS';
    end
    fprintf('%s: %s (actual %.4f, paper %.4f)\n', ...
        field, status, value(1), expected);
end

if nargout == 0
    assert(ok, 'Summary metrics do not match the paper at four decimal places.');
end
end
