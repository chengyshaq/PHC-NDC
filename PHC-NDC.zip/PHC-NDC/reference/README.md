`paper_metrics.csv` stores the paper's reported MIMR baseline and PHC-NDC values for DD and Bridges, rounded to four decimal places. `check_experiment` uses it to check a completed run.
