# Imported components

## LIBSVM

The project bundles LIBSVM 3.20 by Chih-Chung Chang and Chih-Jen Lin, copied
from the dependency used by the active server experiment. The source,
MATLAB interface, original copyright/license text, and Linux x86-64
training/prediction binaries are under `third_party/libsvm/`.

The MATLAB interface contains the local quiet-output handling used in the
existing server installation. Its copied files and hashes are recorded
in `SOURCE_MANIFEST.json`. The original LIBSVM copyright notice is retained
at `third_party/libsvm/COPYRIGHT`.

## HFS-MIMR and hierarchy utilities

The MIMR implementation and its support functions are imported from the
HFS-MIMR implementation used in the author's existing experiments. The
feature selection implementation is under `hfs_mimr/`; original author
headers in its helpers are retained.

The treeFunction, creatSubTable, and evaluation directories
also retain original author headers. These imported functions are not
claimed as new PHC-NDC contributions. `SOURCE_MANIFEST.json` records each
file's source location relative to the existing experiment workspace.

This prepared snapshot does not assign a new project-wide license to
the author's code or to imported MIMR/data components.
