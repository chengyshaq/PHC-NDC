function [prediction, model, detail] = PHCNDC( ...
        trueLabel, trainPredChild, trainChildProb, testPredChild, testChildProb, tree, m0)
%PHCNDC Learn and apply node-directed prediction correction.
% Inputs are labels and outputs of the fixed base node classifiers.
% prediction columns: base, leaf, route, final.
if nargin < 7
    m0 = 10;
end

%% Base predictions
root = tree_Root(tree);
trainBase = TopDownPath(trainPredChild, tree, root);
testBase = TopDownPath(testPredChild, tree, root);

%% Threshold selection and model fitting
[threshold, validation] = CalibrateRepairGainThreshold( ...
    trueLabel, trainBase, trainPredChild, trainChildProb, tree, m0);
model = LearnRepairGain(trueLabel, trainBase, trainPredChild, trainChildProb, tree, m0);

%% Prediction correction
candidates = RepairGainCandidates(testBase, testPredChild, testChildProb, tree, model);
[prediction, fired] = SelectRepairGain(candidates, threshold);

detail.threshold = threshold;
detail.validation = validation;
detail.fired = fired;
detail.gain = [candidates.leafScore, candidates.routeScore];
end
