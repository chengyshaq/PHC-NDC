# PHC-NDC：DD 与 Bridges

本包只包含论文中 MIMR + PHC-NDC 实验使用的 DD 和 Bridges 数据，以及对应的 MIMR 特征、十折节点预测和概率缓存。原有 MIMR 特征选择、SVM 训练与预测源码仍保留。

## MATLAB 运行

在本目录下运行两个数据集：

```matlab
run_all
```

也可以单独运行：

```matlab
run_experiment([], 'DD')
run_experiment([], 'Bridges')
```

结果分别写入 `results/DD` 和 `results/Bridges`。运行完成后，可用下列命令按论文表格的四位小数核对指标：

```matlab
check_experiment([], 'DD')
check_experiment([], 'Bridges')
```

主实验直接读取包内的节点输出缓存，不会重新运行特征选择或训练基础 SVM。
