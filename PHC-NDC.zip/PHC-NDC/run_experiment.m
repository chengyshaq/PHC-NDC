function result = run_experiment(outputDir, dataset)
%RUN_EXPERIMENT Run the paper MIMR + PHC-NDC experiment on DD or Bridges.
root = setup_project;
if nargin < 2 || isempty(dataset)
    dataset = 'DD';
end
dataset = validatestring(char(dataset), {'DD', 'Bridges'});
if nargin < 1 || isempty(outputDir)
    outputDir = fullfile(root, 'results', dataset);
end
if ~exist(outputDir, 'dir')
    mkdir(outputDir);
end
timer = tic;

%% Data and parameters
m0 = 10;
[calibrationLabel, evaluationLabel, tree, testIndices, nodeOutputs] = LoadDataset(root, dataset);
folds = unique(testIndices)';
nFold = numel(folds);
nTest = numel(evaluationLabel);
nCalibration = numel(calibrationLabel);

%% Initialize fold results
predictions = zeros(nTest, 2);
ruleIDs = zeros(nTest, 2);
gainScores = zeros(nTest, 2);
sampleThreshold = zeros(nTest, 1);
foldParameters = zeros(nFold, 6);
gainModels = cell(nFold, 1);
validationInfo = cell(nFold, 1);
validationScan = zeros(0, 8);

%% Ten-fold evaluation
for k = 1:nFold
    fold = folds(k);
    testID = testIndices == fold;
    node = nodeOutputs{k};
    [prediction, model, detail] = PHCNDC(calibrationLabel, ...
        node.trainPredChild, node.trainChildProb, ...
        node.testPredChild, node.testChildProb, tree, m0);

    predictions(testID, :) = prediction(:, [1, 4]);
    ruleIDs(testID, :) = detail.fired;
    gainScores(testID, :) = detail.gain;
    sampleThreshold(testID) = detail.threshold;
    foldParameters(k, :) = [fold, sum(testID), detail.threshold, ...
        size(model.leaf.rules, 1), size(model.route.rules, 1), nCalibration];
    gainModels{k} = model;
    validation = detail.validation;
    validationInfo{k} = validation;
    validationScan = [validationScan; repmat(fold, size(validation.scan, 1), 1), validation.scan]; %#ok<AGROW>
    fprintf('Fold %2d/10: Base %.4f%%, PHC-NDC %.4f%%, threshold %.4g\n', ...
        fold, 100 * mean(prediction(:, 1) == evaluationLabel(testID)), ...
        100 * mean(prediction(:, 4) == evaluationLabel(testID)), detail.threshold);
end

%% Evaluate
foldMetrics = FoldMetrics(evaluationLabel, predictions, testIndices, tree);
average = mean(foldMetrics(:, 3:end), 1);
fixed = sum(predictions(:, 1) ~= evaluationLabel & predictions(:, 2) == evaluationLabel);
broken = sum(predictions(:, 1) == evaluationLabel & predictions(:, 2) ~= evaluationLabel);
changed = sum(predictions(:, 1) ~= predictions(:, 2));

%% Summary
summary.Method = "MIMR";
summary.Dataset = string(dataset);
summary.NTest = nTest;
summary.NCalibration = nCalibration;
summary.M0 = m0;
summary.Regularization = 1e-3;
summary.InnerFolds = 3;
summary.BaseACC = average(1);
summary.BaseFH = average(2);
summary.BaseTIE = average(3);
summary.BaseFLCA = average(4);
summary.PHCNDCACC = average(5);
summary.PHCNDCFH = average(6);
summary.PHCNDCTIE = average(7);
summary.PHCNDCFLCA = average(8);
summary.PHCNDCFixed = fixed;
summary.PHCNDCBroken = broken;
summary.PHCNDCChanged = changed;
summary.PHCNDCNet = fixed - broken;
summaryTable = struct2table(summary);

%% Result tables
sampleHeader = {'SampleId', 'Fold', 'TrueLabel', 'BasePred', 'PHCNDCPred', ...
    'PHCNDCLeafRule', 'PHCNDCRouteRule', 'LeafGain', 'RouteGain', 'SelectedThreshold'};
sampleData = [(1:nTest)', testIndices, evaluationLabel, predictions, ...
    ruleIDs, gainScores, sampleThreshold];
samplePredictions = array2table(sampleData, 'VariableNames', sampleHeader);
foldTable = array2table(foldMetrics, 'VariableNames', ...
    {'Fold', 'N', 'BaseACC', 'BaseFH', 'BaseTIE', 'BaseFLCA', ...
    'PHCNDCACC', 'PHCNDCFH', 'PHCNDCTIE', 'PHCNDCFLCA'});
parameterTable = array2table(foldParameters, 'VariableNames', ...
    {'Fold', 'N', 'Threshold', 'LeafRules', 'RouteRules', 'NCalibration'});
scanTable = array2table(validationScan, 'VariableNames', [{'Fold'}, validationInfo{1}.columns]);

%% Save
writetable(summaryTable, fullfile(outputDir, 'summary.csv'));
writetable(samplePredictions, fullfile(outputDir, 'sample_predictions.csv'));
writetable(foldTable, fullfile(outputDir, 'fold_metrics.csv'));
writetable(parameterTable, fullfile(outputDir, 'fold_parameters.csv'));
writetable(scanTable, fullfile(outputDir, 'validation_scan.csv'));
save(fullfile(outputDir, 'gain_models.mat'), 'gainModels', 'validationInfo', '-v7.3');
result.summary = summaryTable;
result.samplePredictions = samplePredictions;
result.foldMetrics = foldTable;
result.foldParameters = parameterTable;
result.outputDir = outputDir;
result.seconds = toc(timer);

fprintf('[RESULT] MIMR %s Base: ACC %.6f FH %.6f TIE %.6f FLCA %.6f\n', dataset, ...
    summary.BaseACC, summary.BaseFH, summary.BaseTIE, summary.BaseFLCA);
fprintf('[RESULT] MIMR %s PHC-NDC: ACC %.6f FH %.6f TIE %.6f FLCA %.6f\n', dataset, ...
    summary.PHCNDCACC, summary.PHCNDCFH, summary.PHCNDCTIE, summary.PHCNDCFLCA);
fprintf('[COUNTS] Fixed %d Broken %d Changed %d\n', fixed, broken, changed);
end
