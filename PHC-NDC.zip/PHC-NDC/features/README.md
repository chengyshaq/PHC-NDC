# MIMR feature files

`DD_feature.mat` and `Bridges_feature.mat` contain the selected MIMR features and the original ten-fold test assignments for their matching datasets. Their hashes are recorded in `assets/base_outputs/DD/manifest.json` and `assets/base_outputs/Bridges/manifest.json`.
