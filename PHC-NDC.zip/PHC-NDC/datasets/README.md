# Bundled datasets

| Dataset | Training samples | Test samples | Features | Leaf classes | Tree height |
|---|---:|---:|---:|---:|---:|
| DD | 3,020 | 605 | 473 | 27 | 3 |
| Bridges | 108 | 101 | 11 | 6 | 3 |

Each MAT file contains `data_array` and `tree`. Training labels provide correction-calibration data; test samples are evaluated with the original ten-fold assignment stored in the corresponding feature file.
