function predict_label = TopDownPath(predChild, tree, startNode)
[m,~] = size(predChild);
leafNode = tree_LeafNode(tree);
predict_label = zeros(m,1);
for j = 1:m
    currentNode = startNode;
    %% Go down until a leaf node
    while (~ismember(currentNode, leafNode))
        currentNode = predChild(j, currentNode);
    end
    predict_label(j) = currentNode;
end
end
