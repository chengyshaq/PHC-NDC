function [predChild, childProb, hardTime, probTime] = HierSVMPredict(data, tree, models, feature, numberSel)
n = size(data, 1);
numNodes = size(tree, 1);
predChild = nan(n, numNodes);
childProb = nan(n, numNodes);
hardTime = 0;
probTime = 0;
%% Predict the child of each internal node
for currentNode = 1:numNodes
    children_set = models.children{currentNode};
    if (isempty(children_set))
        continue;
    end
    fallback = models.majority(currentNode);
    if (isempty(models.hard{currentNode}))
        predChild(:, currentNode) = fallback;
        for j = 1:length(children_set)
            childProb(:, children_set(j)) = double(children_set(j) == fallback);
        end
        continue;
    end
    selFeature = feature{currentNode};
    if (isempty(selFeature))
        selFeature = 1:size(data,2);
    end
    selFeature = selFeature(1:min(numberSel,numel(selFeature)));
    testData = double(data(:, selFeature));
    hardTimer = tic;
    predChild(:, currentNode) = double(svmpredict(zeros(n,1), testData, models.hard{currentNode}, '-q'));
    hardTime = hardTime + toc(hardTimer);
    probTimer = tic;
    [~, ~, values] = svmpredict(zeros(n,1), testData, models.prob{currentNode}, '-b 1 -q');
    probTime = probTime + toc(probTimer);
    prob = zeros(n, numel(children_set));
    labels = double(models.prob{currentNode}.Label(:));
    for j = 1:numel(children_set)
        k = find(labels == children_set(j), 1);
        if (~isempty(k))
            prob(:,j) = values(:,k);
        end
    end
    childProb(:, children_set) = prob ./ sum(prob, 2);
end
end
