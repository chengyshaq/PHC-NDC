function models = HierSVMTrain(data, tree, feature, numberSel)
tableTimer = tic;
[nodeData, nodeLabel] = creatSubTablezh(data, tree);
tableSeconds = toc(tableTimer);
n = size(tree, 1);
models.hard = cell(n, 1);
models.prob = cell(n, 1);
models.children = cell(n, 1);
models.majority = zeros(n, 1);
models.hardTime = tableSeconds;
models.probTime = 0;
%% Train the SVM of each internal node
for currentNode = 1:n
    children_set = get_children_set(tree, currentNode)';
    models.children{currentNode} = children_set;
    if (isempty(children_set))
        continue;
    end
    trainLabel = double(nodeLabel{currentNode}(:));
    models.majority(currentNode) = children_set(1);
    if (isempty(trainLabel))
        continue;
    end
    counts = zeros(size(children_set));
    for j = 1:length(children_set)
        counts(j) = sum(trainLabel == children_set(j));
    end
    [~, j] = max(counts);
    models.majority(currentNode) = children_set(j);
    if (numel(unique(trainLabel)) == 1)
        continue;
    end
    selFeature = feature{currentNode};
    if (isempty(selFeature))
        selFeature = 1:size(nodeData{currentNode},2);
    end
    selFeature = selFeature(1:min(numberSel,numel(selFeature)));
    trainData = double(nodeData{currentNode}(:, selFeature));
    hardTimer = tic;
    models.hard{currentNode} = svmtrain(trainLabel, trainData, '-c 1 -t 0 -q');
    models.hardTime = models.hardTime + toc(hardTimer);
    probTimer = tic;
    models.prob{currentNode} = svmtrain(trainLabel, trainData, '-c 1 -t 0 -b 1 -q');
    models.probTime = models.probTime + toc(probTimer);
end
end
