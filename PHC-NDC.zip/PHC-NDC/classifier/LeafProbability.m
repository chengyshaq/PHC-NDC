function leafProb = LeafProbability(childProb, tree)
leafNode = tree_LeafNode(tree);
leafProb = zeros(size(childProb,1), numel(leafNode));
for j = 1:numel(leafNode)
    nodePath = tree_Ancestor(tree, leafNode(j), 1);
    leafProb(:,j) = prod(childProb(:,nodePath(1:end-1)), 2);
end
end

